import { useState } from 'react';
import './App.css';

const App = () => {
  // Definir un estado para la lista de tareas
  const [tasks, setTasks] = useState([]);

  // Estado para la tarea que se está ingresando
  const [task, setTask] = useState('');

  // Estado para la tarea que está siendo editada
  const [editingIndex, setEditingIndex] = useState(null);
  const [editingTask, setEditingTask] = useState('');

  // Función para enviar la tarea que se ingresa en el input 
  const addTask = (e) => {
    e.preventDefault();
    if (task.trim() !== '') {
      setTasks([...tasks, task]);
      setTask(''); // Limpia el input
    }
  };

  // Función para eliminar una tarea
  const removeTask = (index) => {
    const updatedTasks = tasks.filter((_, i) => i !== index);
    setTasks(updatedTasks);
  };

  // Función para iniciar la edición de una tarea
  const editTask = (index) => {
    setEditingIndex(index); // Establece la tarea que se está editando
    setEditingTask(tasks[index]); // Muestra el valor actual de la tarea en el input de edición
  };

  // Función para confirmar los cambios en una tarea editada
  const saveEditedTask = (e) => {
    e.preventDefault();
    const updatedTasks = [...tasks];
    updatedTasks[editingIndex] = editingTask; // Actualiza la tarea con el nuevo valor
    setTasks(updatedTasks);
    setEditingIndex(null); // Finaliza el modo de edición
    setEditingTask(''); // Limpia el input de edición
  };

  return (
    <div className="container">
      <h2>Lista de Tareas</h2>
      <form onSubmit={addTask}>
        <input
          type="text"
          value={task}
          onChange={(e) => setTask(e.target.value)}
          placeholder="Ingresa una tarea"
        />
        <button type="submit">Agregar Tarea</button>
      </form>

      <ul>
        {tasks.map((task, index) => (
          <li key={index}>
            {editingIndex === index ? (
              <form onSubmit={saveEditedTask}>
                <input
                  type="text"
                  value={editingTask}
                  onChange={(e) => setEditingTask(e.target.value)}
                />
                <button type="submit">Guardar</button>
              </form>
            ) : (
              <>
                {task}
                <button onClick={() => editTask(index)} style={{ marginLeft: '10px' }}>
                  Editar
                </button>
                <button onClick={() => removeTask(index)} style={{ marginLeft: '10px' }}>
                  Eliminar
                </button>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
